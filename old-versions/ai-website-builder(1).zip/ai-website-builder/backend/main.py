from fastapi import FastAPI, Form
from fastapi.middleware.cors import CORSMiddleware
import openai

app = FastAPI()

# Allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Set your OpenAI API key
openai.api_key = "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"

@app.post("/generate/")
async def generate_website(prompt: str = Form(...)):
    system_prompt = """
    You are a web designer AI. Generate full HTML code with TailwindCSS styling based on user requirements.
    Include complete HTML structure (<html>, <head>, <body>).
    The output should be ready-to-render HTML only, no markdown.
    """

    completion = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
    )

    html_code = completion.choices[0].message.content
    return {"html": html_code}
