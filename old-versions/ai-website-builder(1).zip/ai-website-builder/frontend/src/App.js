import React, { useState } from "react";
import axios from "axios";

function App() {
  const [prompt, setPrompt] = useState("");
  const [html, setHtml] = useState("");

  const generate = async () => {
    const formData = new FormData();
    formData.append("prompt", prompt);
    const res = await axios.post("http://127.0.0.1:8000/generate/", formData);
    setHtml(res.data.html);
  };

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <div style={{ width: "30%", padding: 20, background: "#f5f5f5" }}>
        <h2>AI Website Builder</h2>
        <textarea
          rows="6"
          style={{ width: "100%" }}
          placeholder="Describe your website..."
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
        <button onClick={generate} style={{ marginTop: 10 }}>Generate</button>
      </div>

      <div style={{ width: "70%", borderLeft: "1px solid #ddd" }}>
        <iframe
          title="preview"
          style={{ width: "100%", height: "100%", border: "none" }}
          srcDoc={html}
        />
      </div>
    </div>
  );
}

export default App;

