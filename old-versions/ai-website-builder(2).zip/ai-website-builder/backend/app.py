from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from openai import OpenAI
import os
import uuid
import zipfile

# Initialize FastAPI
app = FastAPI()

# Allow all origins (frontend connection)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# Initialize OpenAI client
client = OpenAI(api_key="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")

# Ensure output folder exists
os.makedirs("generated_projects", exist_ok=True)

@app.post("/generate/")
async def generate_project(request: Request):
    data = await request.json()
    description = data.get("description", "")

    system_prompt = """
    You are an expert full-stack AI developer. 
    Generate complete front-end HTML code with TailwindCSS styling for the user's project description.
    The output must include <html>, <head>, and <body> tags and be production-ready HTML (no markdown).
    """

    # Call OpenAI
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": description}
        ]
    )

    html_code = completion.choices[0].message.content

    # Create folder for project
    project_id = str(uuid.uuid4())[:10]
    project_path = f"generated_projects/{project_id}"
    os.makedirs(project_path, exist_ok=True)

    # Save HTML file
    html_file = os.path.join(project_path, "index_preview.html")
    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_code)

    # Create ZIP archive
    zip_path = f"{project_path}.zip"
    with zipfile.ZipFile(zip_path, "w") as zipf:
        for root, _, files in os.walk(project_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, project_path))

    return {"project_id": project_id, "message": "Project generated successfully."}


@app.get("/generated_projects/{project_id}/index_preview.html")
async def get_project_preview(project_id: str):
    file_path = f"generated_projects/{project_id}/index_preview.html"
    if os.path.exists(file_path):
        return FileResponse(file_path, media_type="text/html")
    return {"error": "Preview file not found."}


@app.get("/download/{project_id}.zip")
async def download_project(project_id: str):
    zip_path = f"generated_projects/{project_id}.zip"
    if os.path.exists(zip_path):
        return FileResponse(zip_path, filename=f"{project_id}.zip")
    return {"error": "ZIP file not found."}
