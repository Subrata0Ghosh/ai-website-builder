```python
from sqlmodel import SQLModel, create_engine, Session

DATABASE_URL = "sqlite:///./portfolio.db"

engine = create_engine(DATABASE_URL)

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

def get_session():
    with Session(engine) as session:
        yield session
```

### Instructions to Run the Project
1. Install the required packages:
   ```bash
   pip install fastapi[all] sqlmodel passlib
   ```

2. Run the FastAPI application:
   ```bash
   uvicorn main:app --reload
   ```

3. Access the API documentation at `http://127.0.0.1:8000/docs`.

This setup provides a basic structure for your portfolio website with authentication and task management. You can further enhance it by adding features like email notifications, input validation, and more.