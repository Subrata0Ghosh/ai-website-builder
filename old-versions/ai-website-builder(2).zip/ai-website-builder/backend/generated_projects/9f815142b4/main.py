```python
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from sqlmodel import SQLModel, Field, create_engine, Session as SQLSession, select
from passlib.context import CryptContext
from typing import List

# Database setup
DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(DATABASE_URL)

# Create the database tables
SQLModel.metadata.create_all(engine)

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# FastAPI app
app = FastAPI()

# OAuth2 setup
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Models
class User(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True)
    hashed_password: str

class Task(SQLModel, table=True):
    id: int = Field(default=None, primary_key=True)
    title: str
    description: str
    owner_id: int = Field(foreign_key="user.id")

# Pydantic models
class UserCreate(SQLModel):
    username: str
    password: str

class UserOut(SQLModel):
    id: int
    username: str

class TaskCreate(SQLModel):
    title: str
    description: str

class TaskOut(Task):
    pass

# Dependency to get the database session
def get_db():
    with SQLSession(engine) as session:
        yield session

# Authentication functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def get_user(db: Session, username: str):
    return db.exec(select(User).where(User.username == username)).first()

@app.post("/signup", response_model=UserOut)
def signup(user: UserCreate, db: Session = Depends(get_db)):
    db_user = get_user(db, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    hashed_password = get_password_hash(user.password)
    new_user = User(username=user.username, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = get_user(db, form_data.username)
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    return {"access_token": user.username, "token_type": "bearer"}

@app.post("/tasks/", response_model=TaskOut)
def create_task(task: TaskCreate, db: Session = Depends(get_db), username: str = Depends(oauth2_scheme)):
    owner = get_user(db, username)
    if not owner:
        raise HTTPException(status_code=400, detail="User not found")
    db_task = Task(title=task.title, description=task.description, owner_id=owner.id)
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.get("/tasks/", response_model=List[TaskOut])
def read_tasks(skip: int = 0, limit: int = 10, db: Session = Depends(get_db), username: str = Depends(oauth2_scheme)):
    owner = get_user(db, username)
    if not owner:
        raise HTTPException(status_code=400, detail="User not found")
    tasks = db.exec(select(Task).where(Task.owner_id == owner.id).offset(skip).limit(limit)).all()
    return tasks

@app.get("/tasks/{task_id}", response_model=TaskOut)
def read_task(task_id: int, db: Session = Depends(get_db), username: str = Depends(oauth2_scheme)):
    owner = get_user(db, username)
    if not owner:
        raise HTTPException(status_code=400, detail="User not found")
    task = db.exec(select(Task).where(Task.id == task_id, Task.owner_id == owner.id)).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

@app.put("/tasks/{task_id}", response_model=TaskOut)
def update_task(task_id: int, task: TaskCreate, db: Session = Depends(get_db), username: str = Depends(oauth2_scheme)):
    owner = get_user(db, username)
    if not owner:
        raise HTTPException(status_code=400, detail="User not found")
    db_task = db.exec(select(Task).where(Task.id == task_id, Task.owner_id == owner.id)).first()
    if not db_task:
        raise HTTPException(status_code=404, detail="Task not found")
    db_task.title = task.title
    db_task.description = task.description
    db.add(db_task)
    db.commit()
    db.refresh(db_task)
    return db_task

@app.delete("/tasks/{task_id}", response_model=TaskOut)
def delete_task(task_id: int, db: Session = Depends(get_db), username: str = Depends(oauth2_scheme)):
    owner = get_user(db, username)
    if not owner:
        raise HTTPException(status_code=400, detail="User not found")
    db_task = db.exec(select(Task).where(Task.id == task_id, Task.owner_id == owner.id)).first()
    if not db_task:
        raise HTTPException(status_code=404, detail="Task not found")
    db.delete(db_task)
    db.commit()
    return db_task
```

### Explanation:
- **Database**: The app uses SQLite with SQLModel for ORM.
- **Models**: There are two models, `User` and `Task`, with corresponding Pydantic models for input and output validation.
- **Authentication**: The app includes signup and login endpoints, using OAuth2 for token-based authentication.
- **CRUD Operations**: The app provides endpoints to create, read, update, and delete tasks, ensuring that tasks are associated with the authenticated user.

You can run this FastAPI application using `uvicorn main:app --reload` and test the endpoints using a tool like Postman or Swagger UI at `http://127.0.0.1:8000/docs`.