import React from "react";
import { getPreviewUrl, getDownloadUrl } from "../api";

const ProjectPreview = ({ projectId }) => {
  if (!projectId) return null;

  const previewUrl = getPreviewUrl(projectId);
  const downloadUrl = getDownloadUrl(projectId);

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold text-gray-800">
        Project ID: {projectId}
      </h2>
      <div className="flex gap-4 mt-2">
        <a
          href={downloadUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600"
        >
          📦 Download Project ZIP
        </a>
        <a
          href={previewUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
        >
          🔍 Preview
        </a>
      </div>

      <iframe
        title="Project Preview"
        src={previewUrl}
        className="w-full h-[500px] border mt-4 rounded-lg"
      />
    </div>
  );
};

export default ProjectPreview;
