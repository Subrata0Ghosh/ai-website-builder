```python
from fastapi import FastAPI
from routes import auth, tasks
from database import create_db_and_tables

app = FastAPI()

# Create the database and tables
create_db_and_tables()

# Include the routes
app.include_router(auth.router)
app.include_router(tasks.router)

@app.get("/")
async def root():
    return {"message": "Welcome to the Portfolio Website API"}
```

###