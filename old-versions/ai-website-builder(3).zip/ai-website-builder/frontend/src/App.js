import React, { useState } from "react";
import { generateProject } from "./api";
import ProjectPreview from "./components/ProjectPreview";
import "./index.css";

export default function App() {
  const [description, setDescription] = useState("");
  const [projectId, setProjectId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleGenerate = async () => {
    if (!description.trim()) return;
    setLoading(true);
    setError("");
    setProjectId(null);

    try {
      const result = await generateProject(description);
      setProjectId(result.project_id);
    } catch (err) {
      setError("Error generating project. Please check backend logs.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-white flex flex-col items-center py-10">
      <h1 className="text-3xl font-bold text-indigo-700 mb-6">
        🚀 AI Project Orchestrator
      </h1>

      <div className="w-full max-w-lg bg-white shadow-md rounded-2xl p-6">
        <textarea
          className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-400"
          rows="3"
          placeholder="Describe your project idea (e.g. Task management app with login and sharing)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full mt-4 bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700 transition"
        >
          {loading ? "Generating..." : "Generate Project"}
        </button>

        {error && <p className="text-red-500 mt-4">{error}</p>}

        {projectId && <ProjectPreview projectId={projectId} />}
      </div>
    </div>
  );
}
